export default {
    "host": "rm-bp1885n5396ao5q8vco.mysql.rds.aliyuncs.com",
    "user": "wangxuan",
    "password": "Wrx2918095@",
    "database": "canteen",
    "connectionLimit": 85
}